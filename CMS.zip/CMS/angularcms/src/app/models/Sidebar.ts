export interface Sidebar {
    _id: string,
    content: string
}